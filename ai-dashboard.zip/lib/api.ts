export interface BlockchainDataPoint {
  timestamp: number
  time: string
  btc: number
  eth: number
  sol: number
  volume: number
  marketCap: number
}

export interface AIAnalysis {
  query: string
  insights: string[]
  predictions: {
    btc: {
      price: number
      confidence: number
      timeframe: string
    }
    eth: {
      price: number
      confidence: number
      timeframe: string
    }
  }
  riskFactors: string[]
}

export async function fetchBlockchainData(): Promise<BlockchainDataPoint[]> {
  const response = await fetch("/api/blockchain-data", {
    cache: "no-store",
  })

  if (!response.ok) {
    throw new Error("Failed to fetch blockchain data")
  }

  const result = await response.json()
  return result.data
}

export async function requestAIAnalysis(query: string): Promise<AIAnalysis> {
  const response = await fetch("/api/ai-analysis", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query }),
  })

  if (!response.ok) {
    throw new Error("Failed to get AI analysis")
  }

  const result = await response.json()
  return result.analysis
}
