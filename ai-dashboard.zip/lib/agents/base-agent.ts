// Base agent class for the agentic AI system
export interface AgentDecision {
  score: number // 0-100
  reasoning: string
  confidence: number // 0-1
  data: Record<string, any>
}

export interface AgentContext {
  fromChain: string
  toChain: string
  amount: number
  token: string
  userPreferences: {
    prioritizeCost: boolean
    prioritizeSpeed: boolean
    prioritizeCarbon: boolean
  }
  marketData: Record<string, any>
}

export abstract class BaseAgent {
  protected name: string
  protected description: string

  constructor(name: string, description: string) {
    this.name = name
    this.description = description
  }

  abstract analyze(context: AgentContext): Promise<AgentDecision>

  getName(): string {
    return this.name
  }

  getDescription(): string {
    return this.description
  }

  protected normalizeScore(value: number, min: number, max: number): number {
    return Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100))
  }

  protected calculateConfidence(factors: number[]): number {
    // Calculate confidence based on data quality and consistency
    const average = factors.reduce((sum, factor) => sum + factor, 0) / factors.length
    const variance = factors.reduce((sum, factor) => sum + Math.pow(factor - average, 2), 0) / factors.length
    return Math.max(0.1, Math.min(1.0, 1 - variance / 100))
  }
}
