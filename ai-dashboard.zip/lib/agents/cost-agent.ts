import { BaseAgent, type AgentDecision, type AgentContext } from "./base-agent"
import { web3API } from "../web3-api"

export class CostAgent extends BaseAgent {
  constructor() {
    super("Cost Agent", "Evaluates transaction fees and finds the most cost-effective routes")
  }

  async analyze(context: AgentContext): Promise<AgentDecision> {
    try {
      // Get bridge routes and analyze costs
      const routes = await web3API.getBridgeRoutes(context.fromChain, context.toChain, context.amount)

      if (routes.length === 0) {
        return {
          score: 0,
          reasoning: "No viable routes found for cost analysis",
          confidence: 0.1,
          data: { routes: [] },
        }
      }

      // Find the cheapest route
      const cheapestRoute = routes.reduce((min, route) => (route.estimatedCost < min.estimatedCost ? route : min))

      // Calculate cost efficiency score
      const maxCost = Math.max(...routes.map((r) => r.estimatedCost))
      const minCost = Math.min(...routes.map((r) => r.estimatedCost))
      const costScore = this.normalizeScore(maxCost - cheapestRoute.estimatedCost, 0, maxCost - minCost)

      // Factor in gas price volatility
      const fromChainData = await web3API.getChainData(context.fromChain)
      const toChainData = await web3API.getChainData(context.toChain)

      const gasVolatilityFactor = this.calculateGasVolatility(fromChainData.gasPrice, toChainData.gasPrice)
      const adjustedScore = costScore * (1 - gasVolatilityFactor * 0.2)

      const reasoning =
        `Cheapest route via ${cheapestRoute.protocol} costs $${cheapestRoute.estimatedCost.toFixed(2)}. ` +
        `This saves $${(maxCost - cheapestRoute.estimatedCost).toFixed(2)} compared to the most expensive option. ` +
        `Gas volatility factor: ${(gasVolatilityFactor * 100).toFixed(1)}%`

      return {
        score: Math.round(adjustedScore),
        reasoning,
        confidence: this.calculateConfidence([costScore, 100 - gasVolatilityFactor * 100]),
        data: {
          cheapestRoute,
          allRoutes: routes,
          savings: maxCost - cheapestRoute.estimatedCost,
          gasVolatility: gasVolatilityFactor,
        },
      }
    } catch (error) {
      console.error("Cost Agent analysis failed:", error)
      return {
        score: 0,
        reasoning: "Failed to analyze costs due to data unavailability",
        confidence: 0.1,
        data: { error: error instanceof Error ? error.message : "Unknown error" },
      }
    }
  }

  private calculateGasVolatility(fromGasPrice: number, toGasPrice: number): number {
    // Simple volatility calculation based on gas price difference
    const avgGasPrice = (fromGasPrice + toGasPrice) / 2
    const gasPriceDiff = Math.abs(fromGasPrice - toGasPrice)
    return Math.min(1, gasPriceDiff / avgGasPrice)
  }
}
