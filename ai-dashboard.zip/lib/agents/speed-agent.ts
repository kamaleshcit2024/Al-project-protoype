import { BaseAgent, type AgentDecision, type AgentContext } from "./base-agent"
import { web3API } from "../web3-api"

export class SpeedAgent extends BaseAgent {
  constructor() {
    super("Speed Agent", "Predicts transaction latency and confirmation times")
  }

  async analyze(context: AgentContext): Promise<AgentDecision> {
    try {
      // Get bridge routes and analyze speed
      const routes = await web3API.getBridgeRoutes(context.fromChain, context.toChain, context.amount)

      if (routes.length === 0) {
        return {
          score: 0,
          reasoning: "No viable routes found for speed analysis",
          confidence: 0.1,
          data: { routes: [] },
        }
      }

      // Find the fastest route
      const fastestRoute = routes.reduce((min, route) => (route.estimatedTime < min.estimatedTime ? route : min))

      // Calculate speed efficiency score
      const maxTime = Math.max(...routes.map((r) => r.estimatedTime))
      const minTime = Math.min(...routes.map((r) => r.estimatedTime))
      const speedScore = this.normalizeScore(maxTime - fastestRoute.estimatedTime, 0, maxTime - minTime)

      // Factor in network congestion
      const fromChainData = await web3API.getChainData(context.fromChain)
      const toChainData = await web3API.getChainData(context.toChain)

      const congestionPenalty = this.calculateCongestionPenalty(fromChainData.congestion, toChainData.congestion)
      const adjustedScore = speedScore * (1 - congestionPenalty)

      // Consider block time reliability
      const blockTimeReliability = this.calculateBlockTimeReliability(fromChainData.blockTime, toChainData.blockTime)
      const finalScore = adjustedScore * blockTimeReliability

      const reasoning =
        `Fastest route via ${fastestRoute.protocol} takes ${fastestRoute.estimatedTime.toFixed(1)} minutes. ` +
        `This saves ${(maxTime - fastestRoute.estimatedTime).toFixed(1)} minutes compared to the slowest option. ` +
        `Network congestion impact: ${(congestionPenalty * 100).toFixed(1)}%`

      return {
        score: Math.round(finalScore),
        reasoning,
        confidence: this.calculateConfidence([speedScore, blockTimeReliability * 100, 100 - congestionPenalty * 100]),
        data: {
          fastestRoute,
          allRoutes: routes,
          timeSaved: maxTime - fastestRoute.estimatedTime,
          congestionPenalty,
          blockTimeReliability,
        },
      }
    } catch (error) {
      console.error("Speed Agent analysis failed:", error)
      return {
        score: 0,
        reasoning: "Failed to analyze speed due to data unavailability",
        confidence: 0.1,
        data: { error: error instanceof Error ? error.message : "Unknown error" },
      }
    }
  }

  private calculateCongestionPenalty(fromCongestion: string, toCongestion: string): number {
    const congestionScores = { low: 0, medium: 0.3, high: 0.6 }
    const fromScore = congestionScores[fromCongestion as keyof typeof congestionScores] || 0
    const toScore = congestionScores[toCongestion as keyof typeof congestionScores] || 0
    return (fromScore + toScore) / 2
  }

  private calculateBlockTimeReliability(fromBlockTime: number, toBlockTime: number): number {
    // Shorter block times are generally more reliable for speed predictions
    const avgBlockTime = (fromBlockTime + toBlockTime) / 2
    return Math.max(0.5, Math.min(1.0, 1 - (avgBlockTime - 1) / 20))
  }
}
