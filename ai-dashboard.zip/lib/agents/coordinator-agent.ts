import { BaseAgent, type AgentDecision, type AgentContext } from "./base-agent"
import { CostAgent } from "./cost-agent"
import { SpeedAgent } from "./speed-agent"
import { CarbonAgent } from "./carbon-agent"

interface CoordinatorDecision extends AgentDecision {
  agentScores: {
    cost: AgentDecision
    speed: AgentDecision
    carbon: AgentDecision
  }
  weightedScore: number
  recommendation: {
    route: any
    explanation: string
  }
}

export class CoordinatorAgent extends BaseAgent {
  private costAgent: CostAgent
  private speedAgent: SpeedAgent
  private carbonAgent: CarbonAgent

  constructor() {
    super("Coordinator Agent", "Balances all factors and proposes the optimal route")
    this.costAgent = new CostAgent()
    this.speedAgent = new SpeedAgent()
    this.carbonAgent = new CarbonAgent()
  }

  async analyze(context: AgentContext): Promise<CoordinatorDecision> {
    try {
      // Get decisions from all specialized agents
      const [costDecision, speedDecision, carbonDecision] = await Promise.all([
        this.costAgent.analyze(context),
        this.speedAgent.analyze(context),
        this.carbonAgent.analyze(context),
      ])

      // Calculate weights based on user preferences
      const weights = this.calculateWeights(context.userPreferences)

      // Calculate weighted score
      const weightedScore =
        costDecision.score * weights.cost + speedDecision.score * weights.speed + carbonDecision.score * weights.carbon

      // Determine the best route based on weighted analysis
      const recommendation = this.generateRecommendation(costDecision, speedDecision, carbonDecision, weights)

      // Calculate overall confidence
      const overallConfidence = this.calculateConfidence([
        costDecision.confidence * 100,
        speedDecision.confidence * 100,
        carbonDecision.confidence * 100,
      ])

      const reasoning = this.generateCoordinatorReasoning(
        costDecision,
        speedDecision,
        carbonDecision,
        weights,
        recommendation,
      )

      return {
        score: Math.round(weightedScore),
        reasoning,
        confidence: overallConfidence,
        data: {
          weights,
          recommendation: recommendation.route,
        },
        agentScores: {
          cost: costDecision,
          speed: speedDecision,
          carbon: carbonDecision,
        },
        weightedScore,
        recommendation,
      }
    } catch (error) {
      console.error("Coordinator Agent analysis failed:", error)
      return {
        score: 0,
        reasoning: "Failed to coordinate agent decisions",
        confidence: 0.1,
        data: { error: error instanceof Error ? error.message : "Unknown error" },
        agentScores: {
          cost: { score: 0, reasoning: "Error", confidence: 0, data: {} },
          speed: { score: 0, reasoning: "Error", confidence: 0, data: {} },
          carbon: { score: 0, reasoning: "Error", confidence: 0, data: {} },
        },
        weightedScore: 0,
        recommendation: {
          route: null,
          explanation: "Unable to generate recommendation due to error",
        },
      }
    }
  }

  private calculateWeights(preferences: AgentContext["userPreferences"]) {
    // Default equal weights
    let costWeight = 0.33
    let speedWeight = 0.33
    let carbonWeight = 0.34

    // Adjust weights based on user preferences
    const activePreferences = [
      preferences.prioritizeCost,
      preferences.prioritizeSpeed,
      preferences.prioritizeCarbon,
    ].filter(Boolean).length

    if (activePreferences === 0) {
      // No specific preferences, use balanced approach
      return { cost: costWeight, speed: speedWeight, carbon: carbonWeight }
    }

    // Reset weights and redistribute
    costWeight = speedWeight = carbonWeight = 0

    const preferenceWeight = 1 / activePreferences
    if (preferences.prioritizeCost) costWeight = preferenceWeight
    if (preferences.prioritizeSpeed) speedWeight = preferenceWeight
    if (preferences.prioritizeCarbon) carbonWeight = preferenceWeight

    return { cost: costWeight, speed: speedWeight, carbon: carbonWeight }
  }

  private generateRecommendation(
    costDecision: AgentDecision,
    speedDecision: AgentDecision,
    carbonDecision: AgentDecision,
    weights: { cost: number; speed: number; carbon: number },
  ) {
    // Get the best route from each agent
    const costRoute = costDecision.data.cheapestRoute
    const speedRoute = speedDecision.data.fastestRoute
    const carbonRoute = carbonDecision.data.greenestRoute

    // Score each route based on all factors
    const routes = [costRoute, speedRoute, carbonRoute].filter(Boolean)
    const uniqueRoutes = routes.filter(
      (route, index, self) => index === self.findIndex((r) => r?.protocol === route?.protocol),
    )

    if (uniqueRoutes.length === 0) {
      return {
        route: null,
        explanation: "No viable routes found",
      }
    }

    // Calculate composite scores for each unique route
    const routeScores = uniqueRoutes.map((route) => {
      const costScore = this.scoreRouteForFactor(route, costDecision.data.allRoutes, "estimatedCost", true)
      const speedScore = this.scoreRouteForFactor(route, speedDecision.data.allRoutes, "estimatedTime", true)
      const carbonScore = this.scoreRouteForFactor(route, carbonDecision.data.allRoutes, "carbonFootprint", true)

      const compositeScore = costScore * weights.cost + speedScore * weights.speed + carbonScore * weights.carbon

      return { route, compositeScore, costScore, speedScore, carbonScore }
    })

    // Find the best route
    const bestRoute = routeScores.reduce((best, current) =>
      current.compositeScore > best.compositeScore ? current : best,
    )

    const explanation =
      `Recommended ${bestRoute.route.protocol} based on weighted analysis: ` +
      `Cost efficiency: ${bestRoute.costScore.toFixed(1)}/100, ` +
      `Speed efficiency: ${bestRoute.speedScore.toFixed(1)}/100, ` +
      `Carbon efficiency: ${bestRoute.carbonScore.toFixed(1)}/100`

    return {
      route: bestRoute.route,
      explanation,
    }
  }

  private scoreRouteForFactor(route: any, allRoutes: any[], factor: string, lowerIsBetter: boolean): number {
    if (!route || !allRoutes || allRoutes.length === 0) return 0

    const values = allRoutes.map((r) => r[factor])
    const max = Math.max(...values)
    const min = Math.min(...values)

    if (max === min) return 100

    const routeValue = route[factor]
    if (lowerIsBetter) {
      return this.normalizeScore(max - routeValue, 0, max - min)
    } else {
      return this.normalizeScore(routeValue - min, 0, max - min)
    }
  }

  private generateCoordinatorReasoning(
    costDecision: AgentDecision,
    speedDecision: AgentDecision,
    carbonDecision: AgentDecision,
    weights: { cost: number; speed: number; carbon: number },
    recommendation: { route: any; explanation: string },
  ): string {
    const weightDescriptions = []
    if (weights.cost > 0) weightDescriptions.push(`Cost (${(weights.cost * 100).toFixed(0)}%)`)
    if (weights.speed > 0) weightDescriptions.push(`Speed (${(weights.speed * 100).toFixed(0)}%)`)
    if (weights.carbon > 0) weightDescriptions.push(`Carbon (${(weights.carbon * 100).toFixed(0)}%)`)

    return (
      `Coordinated analysis with weights: ${weightDescriptions.join(", ")}. ` +
      `${recommendation.explanation}. ` +
      `Agent confidence levels: Cost ${(costDecision.confidence * 100).toFixed(0)}%, ` +
      `Speed ${(speedDecision.confidence * 100).toFixed(0)}%, ` +
      `Carbon ${(carbonDecision.confidence * 100).toFixed(0)}%`
    )
  }
}
