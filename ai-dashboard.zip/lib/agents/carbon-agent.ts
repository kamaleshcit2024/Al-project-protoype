import { BaseAgent, type AgentDecision, type AgentContext } from "./base-agent"
import { web3API } from "../web3-api"

export class CarbonAgent extends BaseAgent {
  constructor() {
    super("Carbon Agent", "Estimates energy usage and carbon footprint per chain")
  }

  async analyze(context: AgentContext): Promise<AgentDecision> {
    try {
      // Get bridge routes and analyze carbon footprint
      const routes = await web3API.getBridgeRoutes(context.fromChain, context.toChain, context.amount)

      if (routes.length === 0) {
        return {
          score: 0,
          reasoning: "No viable routes found for carbon analysis",
          confidence: 0.1,
          data: { routes: [] },
        }
      }

      // Find the most eco-friendly route
      const greenestRoute = routes.reduce((min, route) => (route.carbonFootprint < min.carbonFootprint ? route : min))

      // Calculate carbon efficiency score
      const maxCarbon = Math.max(...routes.map((r) => r.carbonFootprint))
      const minCarbon = Math.min(...routes.map((r) => r.carbonFootprint))
      const carbonScore = this.normalizeScore(maxCarbon - greenestRoute.carbonFootprint, 0, maxCarbon - minCarbon)

      // Factor in chain sustainability metrics
      const fromChainData = await web3API.getChainData(context.fromChain)
      const toChainData = await web3API.getChainData(context.toChain)

      const sustainabilityBonus = this.calculateSustainabilityBonus(
        fromChainData.carbonIntensity,
        toChainData.carbonIntensity,
      )
      const adjustedScore = Math.min(100, carbonScore + sustainabilityBonus)

      // Consider renewable energy usage (mock data for demo)
      const renewableEnergyFactor = this.estimateRenewableEnergyUsage(context.fromChain, context.toChain)
      const finalScore = adjustedScore * renewableEnergyFactor

      const carbonSaved = maxCarbon - greenestRoute.carbonFootprint
      const reasoning =
        `Most eco-friendly route via ${greenestRoute.protocol} produces ${greenestRoute.carbonFootprint.toFixed(3)} kg CO₂. ` +
        `This saves ${carbonSaved.toFixed(3)} kg CO₂ (${((carbonSaved / maxCarbon) * 100).toFixed(1)}%) compared to the highest-emission option. ` +
        `Estimated renewable energy usage: ${(renewableEnergyFactor * 100).toFixed(1)}%`

      return {
        score: Math.round(finalScore),
        reasoning,
        confidence: this.calculateConfidence([carbonScore, renewableEnergyFactor * 100, sustainabilityBonus]),
        data: {
          greenestRoute,
          allRoutes: routes,
          carbonSaved,
          renewableEnergyFactor,
          sustainabilityBonus,
        },
      }
    } catch (error) {
      console.error("Carbon Agent analysis failed:", error)
      return {
        score: 0,
        reasoning: "Failed to analyze carbon footprint due to data unavailability",
        confidence: 0.1,
        data: { error: error instanceof Error ? error.message : "Unknown error" },
      }
    }
  }

  private calculateSustainabilityBonus(fromCarbonIntensity: number, toCarbonIntensity: number): number {
    // Bonus points for using low-carbon chains
    const avgIntensity = (fromCarbonIntensity + toCarbonIntensity) / 2
    if (avgIntensity < 0.2) return 20 // High bonus for very green chains
    if (avgIntensity < 0.5) return 10 // Medium bonus for moderately green chains
    return 0 // No bonus for high-carbon chains
  }

  private estimateRenewableEnergyUsage(fromChain: string, toChain: string): number {
    // Mock renewable energy percentages for different chains
    const renewablePercentages: Record<string, number> = {
      ethereum: 0.25, // Post-merge Ethereum
      polygon: 0.6, // More sustainable PoS
      arbitrum: 0.3, // L2 efficiency
      optimism: 0.35, // L2 efficiency
      avalanche: 0.5, // Sustainable consensus
      bsc: 0.2, // Lower sustainability
    }

    const fromRenewable = renewablePercentages[fromChain] || 0.3
    const toRenewable = renewablePercentages[toChain] || 0.3
    return (fromRenewable + toRenewable) / 2
  }
}
