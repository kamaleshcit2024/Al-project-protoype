// Environment configuration and validation
interface EnvironmentConfig {
  // App Configuration
  appName: string
  appVersion: string
  environment: "development" | "production" | "staging"

  // API Keys (with fallbacks for demo)
  alchemyApiKey: string
  infuraApiKey: string
  covalentApiKey: string
  climatiqApiKey: string

  // Feature Flags
  enableRealTimeData: boolean
  enableAdvancedOptimization: boolean
  enableCarbonTracking: boolean

  // Performance Settings
  maxConcurrentRequests: number
  cacheTimeout: number
  rateLimitPerMinute: number
}

class EnvironmentManager {
  private config: EnvironmentConfig

  constructor() {
    this.config = this.loadConfiguration()
    this.validateConfiguration()
  }

  private loadConfiguration(): EnvironmentConfig {
    return {
      // App Configuration
      appName: process.env.NEXT_PUBLIC_APP_NAME || "ECOnodes.AI DeFi Optimizer",
      appVersion: process.env.NEXT_PUBLIC_APP_VERSION || "1.0.0",
      environment: (process.env.NODE_ENV as any) || "development",

      alchemyApiKey: process.env.ALCHEMY_API_KEY || "demo-alchemy-key",
      infuraApiKey: process.env.INFURA_API_KEY || "demo-infura-key",
      covalentApiKey: process.env.COVALENT_API_KEY || "demo-covalent-key",
      climatiqApiKey: process.env.CLIMATIQ_API_KEY || "demo-climatiq-key",

      // Feature Flags
      enableRealTimeData: process.env.ENABLE_REAL_TIME_DATA === "true",
      enableAdvancedOptimization: process.env.ENABLE_ADVANCED_OPTIMIZATION !== "false",
      enableCarbonTracking: process.env.ENABLE_CARBON_TRACKING !== "false",

      // Performance Settings
      maxConcurrentRequests: Number.parseInt(process.env.MAX_CONCURRENT_REQUESTS || "10"),
      cacheTimeout: Number.parseInt(process.env.CACHE_TIMEOUT || "300"), // 5 minutes
      rateLimitPerMinute: Number.parseInt(process.env.RATE_LIMIT_PER_MINUTE || "100"),
    }
  }

  private validateConfiguration(): void {
    const errors: string[] = []

    // Validate required environment variables in production
    if (this.config.environment === "production") {
      if (this.config.alchemyApiKey === "demo-alchemy-key") {
        console.warn("⚠️  Using demo Alchemy API key in production")
      }
      if (this.config.infuraApiKey === "demo-infura-key") {
        console.warn("⚠️  Using demo Infura API key in production")
      }
    }

    // Validate numeric values
    if (this.config.maxConcurrentRequests <= 0) {
      errors.push("MAX_CONCURRENT_REQUESTS must be greater than 0")
    }
    if (this.config.cacheTimeout < 0) {
      errors.push("CACHE_TIMEOUT must be non-negative")
    }
    if (this.config.rateLimitPerMinute <= 0) {
      errors.push("RATE_LIMIT_PER_MINUTE must be greater than 0")
    }

    if (errors.length > 0) {
      throw new Error(`Environment configuration errors:\n${errors.join("\n")}`)
    }
  }

  getConfig(): EnvironmentConfig {
    return { ...this.config }
  }

  isProduction(): boolean {
    return this.config.environment === "production"
  }

  isDevelopment(): boolean {
    return this.config.environment === "development"
  }

  isFeatureEnabled(
    feature: keyof Pick<
      EnvironmentConfig,
      "enableRealTimeData" | "enableAdvancedOptimization" | "enableCarbonTracking"
    >,
  ): boolean {
    return this.config[feature]
  }

  getApiKey(service: "alchemy" | "infura" | "covalent" | "climatiq"): string {
    switch (service) {
      case "alchemy":
        return this.config.alchemyApiKey
      case "infura":
        return this.config.infuraApiKey
      case "covalent":
        return this.config.covalentApiKey
      case "climatiq":
        return this.config.climatiqApiKey
      default:
        throw new Error(`Unknown service: ${service}`)
    }
  }
}

export const environmentManager = new EnvironmentManager()
export const config = environmentManager.getConfig()
