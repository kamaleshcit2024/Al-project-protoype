#!/usr/bin/env node

/**
 * Production setup script for ECOnodes.AI DeFi Optimizer
 * Validates environment, checks dependencies, and prepares for deployment
 */

const fs = require("fs")
const path = require("path")

console.log("🚀 Setting up ECOnodes.AI DeFi Optimizer for production...\n")

// Check Node.js version
const nodeVersion = process.version
const requiredNodeVersion = "18.0.0"
console.log(`📋 Node.js version: ${nodeVersion}`)

if (nodeVersion < `v${requiredNodeVersion}`) {
  console.error(`❌ Node.js ${requiredNodeVersion} or higher is required`)
  process.exit(1)
}

// Check if required files exist
const requiredFiles = ["package.json", "next.config.mjs", "app/layout.tsx", "app/page.tsx"]

console.log("📁 Checking required files...")
for (const file of requiredFiles) {
  if (!fs.existsSync(file)) {
    console.error(`❌ Required file missing: ${file}`)
    process.exit(1)
  }
  console.log(`✅ ${file}`)
}

// Check environment variables
console.log("\n🔧 Checking environment configuration...")
const requiredEnvVars = ["NEXT_PUBLIC_APP_NAME", "NEXT_PUBLIC_APP_VERSION"]

const optionalEnvVars = ["ALCHEMY_API_KEY", "INFURA_API_KEY", "COVALENT_API_KEY", "CLIMATIQ_API_KEY"]

// Check if .env.local exists
if (!fs.existsSync(".env.local") && !fs.existsSync(".env")) {
  console.warn("⚠️  No .env.local or .env file found")
  console.log("📝 Copy .env.example to .env.local and configure your API keys")
}

// Validate package.json
console.log("\n📦 Validating package.json...")
const packageJson = JSON.parse(fs.readFileSync("package.json", "utf8"))

if (!packageJson.scripts.build) {
  console.error("❌ Missing build script in package.json")
  process.exit(1)
}

if (!packageJson.scripts.start) {
  console.error("❌ Missing start script in package.json")
  process.exit(1)
}

console.log("✅ Package.json is valid")

// Check dependencies
console.log("\n📚 Checking critical dependencies...")
const criticalDeps = ["next", "react", "react-dom", "tailwindcss"]

for (const dep of criticalDeps) {
  if (!packageJson.dependencies[dep] && !packageJson.devDependencies[dep]) {
    console.error(`❌ Missing critical dependency: ${dep}`)
    process.exit(1)
  }
  console.log(`✅ ${dep}`)
}

// Create production checklist
console.log("\n📋 Production Deployment Checklist:")
console.log("□ Set up API keys in Vercel environment variables")
console.log("□ Configure custom domain (optional)")
console.log("□ Set up monitoring and analytics")
console.log("□ Test all API endpoints")
console.log("□ Verify cross-chain functionality")
console.log("□ Check AI agent responses")
console.log("□ Validate optimization algorithms")
console.log("□ Test error handling and fallbacks")

console.log("\n✨ Production setup complete!")
console.log("🚀 Ready to deploy to Vercel with: vercel --prod")
console.log("📖 See README.md for detailed deployment instructions")
