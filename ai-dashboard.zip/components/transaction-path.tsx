"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, CheckCircle, Clock, Zap } from "lucide-react"

const pathSteps = [
  {
    chain: "Ethereum",
    action: "Bridge to Polygon",
    status: "completed",
    time: "1.2 min",
    cost: "$8.50",
    color: "bg-blue-500",
  },
  {
    chain: "Polygon",
    action: "Swap & Bridge to Arbitrum",
    status: "processing",
    time: "2.0 min",
    cost: "$3.95",
    color: "bg-purple-500",
  },
  {
    chain: "Arbitrum",
    action: "Final Settlement",
    status: "pending",
    time: "0.5 min",
    cost: "$0.15",
    color: "bg-cyan-500",
  },
]

export function TransactionPath() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Transaction Path Visualization
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {pathSteps.map((step, index) => (
            <div key={index} className="flex items-center gap-4">
              {/* Chain Icon */}
              <div
                className={`w-12 h-12 rounded-full ${step.color} flex items-center justify-center text-white font-bold text-sm`}
              >
                {step.chain.slice(0, 3).toUpperCase()}
              </div>

              {/* Step Details */}
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold">{step.chain}</h4>
                  <Badge
                    variant={
                      step.status === "completed" ? "default" : step.status === "processing" ? "secondary" : "outline"
                    }
                  >
                    {step.status === "completed" && <CheckCircle className="h-3 w-3 mr-1" />}
                    {step.status === "processing" && <Clock className="h-3 w-3 mr-1 animate-pulse" />}
                    {step.status === "pending" && <Clock className="h-3 w-3 mr-1" />}
                    {step.status.charAt(0).toUpperCase() + step.status.slice(1)}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{step.action}</p>
                <div className="flex gap-4 text-xs text-muted-foreground">
                  <span>⏱️ {step.time}</span>
                  <span>💰 {step.cost}</span>
                </div>
              </div>

              {/* Arrow */}
              {index < pathSteps.length - 1 && <ArrowRight className="h-5 w-5 text-muted-foreground" />}
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="mt-6 p-4 bg-muted/50 rounded-lg">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-sm text-muted-foreground">Total Time</div>
              <div className="font-semibold">3.7 min</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Total Cost</div>
              <div className="font-semibold">$12.60</div>
            </div>
            <div>
              <div className="text-sm text-muted-foreground">Gas Saved</div>
              <div className="font-semibold text-green-600">40%</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
