"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Settings, User, Bell, Shield, Palette, Save } from "lucide-react"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"

interface UserSettings {
  profile: {
    name: string
    email: string
    avatar: string
    timezone: string
    currency: string
  }
  notifications: {
    emailAlerts: boolean
    pushNotifications: boolean
    priceAlerts: boolean
    portfolioUpdates: boolean
    marketNews: boolean
  }
  display: {
    theme: "light" | "dark" | "system"
    language: string
    dateFormat: string
    numberFormat: string
  }
  privacy: {
    profileVisibility: "public" | "private"
    dataSharing: boolean
    analytics: boolean
    twoFactorAuth: boolean
  }
}

export function UserSettings() {
  const { toast } = useToast()
  const [settings, setSettings] = useState<UserSettings>({
    profile: {
      name: "Alex Johnson",
      email: "alex.johnson@example.com",
      avatar: "",
      timezone: "UTC-5",
      currency: "USD",
    },
    notifications: {
      emailAlerts: true,
      pushNotifications: true,
      priceAlerts: true,
      portfolioUpdates: false,
      marketNews: true,
    },
    display: {
      theme: "system",
      language: "en",
      dateFormat: "MM/DD/YYYY",
      numberFormat: "US",
    },
    privacy: {
      profileVisibility: "private",
      dataSharing: false,
      analytics: true,
      twoFactorAuth: false,
    },
  })

  const [hasChanges, setHasChanges] = useState(false)

  const updateSetting = (section: keyof UserSettings, key: string, value: any) => {
    setSettings((prev) => ({
      ...prev,
      [section]: {
        ...prev[section],
        [key]: value,
      },
    }))
    setHasChanges(true)
  }

  const saveSettings = () => {
    // Simulate saving settings
    setTimeout(() => {
      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully.",
      })
      setHasChanges(false)
    }, 500)
  }

  const resetSettings = () => {
    // Reset to default values
    toast({
      title: "Settings Reset",
      description: "All settings have been reset to default values.",
    })
    setHasChanges(false)
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Settings className="h-5 w-5" />
            ECOnodes.AI Settings
          </CardTitle>
          <CardDescription>Manage your account preferences and dashboard settings</CardDescription>
        </div>
        <div className="flex items-center gap-2">
          {hasChanges && (
            <Button variant="outline" size="sm" onClick={resetSettings}>
              Reset
            </Button>
          )}
          <Button size="sm" onClick={saveSettings} disabled={!hasChanges} className="gap-2">
            <Save className="h-4 w-4" />
            Save Changes
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile" className="gap-2">
              <User className="h-4 w-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="notifications" className="gap-2">
              <Bell className="h-4 w-4" />
              Notifications
            </TabsTrigger>
            <TabsTrigger value="display" className="gap-2">
              <Palette className="h-4 w-4" />
              Display
            </TabsTrigger>
            <TabsTrigger value="privacy" className="gap-2">
              <Shield className="h-4 w-4" />
              Privacy
            </TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6 mt-6">
            <div className="flex items-center gap-6">
              <Avatar className="w-20 h-20">
                <AvatarImage src={settings.profile.avatar || "/placeholder.svg"} />
                <AvatarFallback className="text-lg">
                  {settings.profile.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-2">
                <Button variant="outline" size="sm">
                  Change Avatar
                </Button>
                <p className="text-sm text-muted-foreground">JPG, PNG or GIF. Max size 2MB.</p>
              </div>
            </div>

            <Separator />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  value={settings.profile.name}
                  onChange={(e) => updateSetting("profile", "name", e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="email">Email Address</Label>
                <Input
                  id="email"
                  type="email"
                  value={settings.profile.email}
                  onChange={(e) => updateSetting("profile", "email", e.target.value)}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="timezone">Timezone</Label>
                <Select
                  value={settings.profile.timezone}
                  onValueChange={(value) => updateSetting("profile", "timezone", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="UTC-8">Pacific Time (UTC-8)</SelectItem>
                    <SelectItem value="UTC-5">Eastern Time (UTC-5)</SelectItem>
                    <SelectItem value="UTC+0">GMT (UTC+0)</SelectItem>
                    <SelectItem value="UTC+1">Central European (UTC+1)</SelectItem>
                    <SelectItem value="UTC+8">Singapore (UTC+8)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="currency">Default Currency</Label>
                <Select
                  value={settings.profile.currency}
                  onValueChange={(value) => updateSetting("profile", "currency", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">US Dollar (USD)</SelectItem>
                    <SelectItem value="EUR">Euro (EUR)</SelectItem>
                    <SelectItem value="GBP">British Pound (GBP)</SelectItem>
                    <SelectItem value="JPY">Japanese Yen (JPY)</SelectItem>
                    <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="notifications" className="space-y-6 mt-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Email Alerts</Label>
                  <p className="text-sm text-muted-foreground">Receive important updates via email</p>
                </div>
                <Switch
                  checked={settings.notifications.emailAlerts}
                  onCheckedChange={(checked) => updateSetting("notifications", "emailAlerts", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Push Notifications</Label>
                  <p className="text-sm text-muted-foreground">Get real-time notifications in your browser</p>
                </div>
                <Switch
                  checked={settings.notifications.pushNotifications}
                  onCheckedChange={(checked) => updateSetting("notifications", "pushNotifications", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Price Alerts</Label>
                  <p className="text-sm text-muted-foreground">Notifications when price targets are hit</p>
                </div>
                <Switch
                  checked={settings.notifications.priceAlerts}
                  onCheckedChange={(checked) => updateSetting("notifications", "priceAlerts", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Portfolio Updates</Label>
                  <p className="text-sm text-muted-foreground">Daily portfolio performance summaries</p>
                </div>
                <Switch
                  checked={settings.notifications.portfolioUpdates}
                  onCheckedChange={(checked) => updateSetting("notifications", "portfolioUpdates", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Market News</Label>
                  <p className="text-sm text-muted-foreground">Important market news and updates</p>
                </div>
                <Switch
                  checked={settings.notifications.marketNews}
                  onCheckedChange={(checked) => updateSetting("notifications", "marketNews", checked)}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="display" className="space-y-6 mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <Label htmlFor="theme">Theme</Label>
                <Select
                  value={settings.display.theme}
                  onValueChange={(value: any) => updateSetting("display", "theme", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="language">Language</Label>
                <Select
                  value={settings.display.language}
                  onValueChange={(value) => updateSetting("display", "language", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Español</SelectItem>
                    <SelectItem value="fr">Français</SelectItem>
                    <SelectItem value="de">Deutsch</SelectItem>
                    <SelectItem value="ja">日本語</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="dateFormat">Date Format</Label>
                <Select
                  value={settings.display.dateFormat}
                  onValueChange={(value) => updateSetting("display", "dateFormat", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                    <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                    <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="numberFormat">Number Format</Label>
                <Select
                  value={settings.display.numberFormat}
                  onValueChange={(value) => updateSetting("display", "numberFormat", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="US">US (1,234.56)</SelectItem>
                    <SelectItem value="EU">EU (1.234,56)</SelectItem>
                    <SelectItem value="IN">IN (1,23,456.78)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="privacy" className="space-y-6 mt-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="profileVisibility">Profile Visibility</Label>
                <Select
                  value={settings.privacy.profileVisibility}
                  onValueChange={(value: any) => updateSetting("privacy", "profileVisibility", value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Public</SelectItem>
                    <SelectItem value="private">Private</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Data Sharing</Label>
                  <p className="text-sm text-muted-foreground">Share anonymized data to improve our services</p>
                </div>
                <Switch
                  checked={settings.privacy.dataSharing}
                  onCheckedChange={(checked) => updateSetting("privacy", "dataSharing", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Analytics</Label>
                  <p className="text-sm text-muted-foreground">Help us improve by sharing usage analytics</p>
                </div>
                <Switch
                  checked={settings.privacy.analytics}
                  onCheckedChange={(checked) => updateSetting("privacy", "analytics", checked)}
                />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <Label className="text-base">Two-Factor Authentication</Label>
                  <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
                </div>
                <Switch
                  checked={settings.privacy.twoFactorAuth}
                  onCheckedChange={(checked) => updateSetting("privacy", "twoFactorAuth", checked)}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
