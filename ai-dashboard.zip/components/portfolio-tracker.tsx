"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Plus, TrendingUp, TrendingDown, DollarSign } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface PortfolioItem {
  id: string
  symbol: string
  name: string
  amount: number
  currentPrice: number
  purchasePrice: number
  change24h: number
}

export function PortfolioTracker() {
  const [portfolio, setPortfolio] = useState<PortfolioItem[]>([
    {
      id: "1",
      symbol: "BTC",
      name: "Bitcoin",
      amount: 0.5,
      currentPrice: 43250,
      purchasePrice: 41000,
      change24h: 2.3,
    },
    {
      id: "2",
      symbol: "ETH",
      name: "Ethereum",
      amount: 2.8,
      currentPrice: 2650,
      purchasePrice: 2400,
      change24h: -1.2,
    },
    {
      id: "3",
      symbol: "ADA",
      name: "Cardano",
      amount: 1000,
      currentPrice: 0.48,
      purchasePrice: 0.52,
      change24h: 4.1,
    },
  ])

  const [newAsset, setNewAsset] = useState({
    symbol: "",
    name: "",
    amount: "",
    purchasePrice: "",
  })

  const totalValue = portfolio.reduce((sum, item) => sum + item.amount * item.currentPrice, 0)
  const totalCost = portfolio.reduce((sum, item) => sum + item.amount * item.purchasePrice, 0)
  const totalPnL = totalValue - totalCost
  const totalPnLPercent = ((totalValue - totalCost) / totalCost) * 100

  const addAsset = () => {
    if (newAsset.symbol && newAsset.amount && newAsset.purchasePrice) {
      const asset: PortfolioItem = {
        id: Date.now().toString(),
        symbol: newAsset.symbol.toUpperCase(),
        name: newAsset.name || newAsset.symbol,
        amount: Number.parseFloat(newAsset.amount),
        currentPrice: Number.parseFloat(newAsset.purchasePrice) * (1 + Math.random() * 0.2 - 0.1), // Mock current price
        purchasePrice: Number.parseFloat(newAsset.purchasePrice),
        change24h: Math.random() * 10 - 5, // Mock 24h change
      }
      setPortfolio([...portfolio, asset])
      setNewAsset({ symbol: "", name: "", amount: "", purchasePrice: "" })
    }
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="text-xl font-bold">Portfolio Tracker</CardTitle>
          <CardDescription>Monitor your cryptocurrency investments</CardDescription>
        </div>
        <Dialog>
          <DialogTrigger asChild>
            <Button size="sm" className="gap-2">
              <Plus className="h-4 w-4" />
              Add Asset
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Asset</DialogTitle>
              <DialogDescription>Add a cryptocurrency to your portfolio</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="symbol">Symbol</Label>
                <Input
                  id="symbol"
                  placeholder="BTC, ETH, ADA..."
                  value={newAsset.symbol}
                  onChange={(e) => setNewAsset({ ...newAsset, symbol: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="name">Name (Optional)</Label>
                <Input
                  id="name"
                  placeholder="Bitcoin, Ethereum..."
                  value={newAsset.name}
                  onChange={(e) => setNewAsset({ ...newAsset, name: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="amount">Amount</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.00000001"
                  placeholder="0.5"
                  value={newAsset.amount}
                  onChange={(e) => setNewAsset({ ...newAsset, amount: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="purchasePrice">Purchase Price ($)</Label>
                <Input
                  id="purchasePrice"
                  type="number"
                  step="0.01"
                  placeholder="41000"
                  value={newAsset.purchasePrice}
                  onChange={(e) => setNewAsset({ ...newAsset, purchasePrice: e.target.value })}
                />
              </div>
              <Button onClick={addAsset} className="w-full">
                Add to Portfolio
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Portfolio Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              <DollarSign className="h-4 w-4" />
              Total Value
            </div>
            <div className="text-2xl font-bold">${totalValue.toLocaleString()}</div>
          </div>
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground mb-1">
              {totalPnL >= 0 ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
              Total P&L
            </div>
            <div className={`text-2xl font-bold ${totalPnL >= 0 ? "text-green-600" : "text-red-600"}`}>
              ${Math.abs(totalPnL).toLocaleString()}
            </div>
          </div>
          <div className="bg-muted/50 rounded-lg p-4">
            <div className="text-sm text-muted-foreground mb-1">P&L %</div>
            <div className={`text-2xl font-bold ${totalPnLPercent >= 0 ? "text-green-600" : "text-red-600"}`}>
              {totalPnLPercent >= 0 ? "+" : ""}
              {totalPnLPercent.toFixed(2)}%
            </div>
          </div>
        </div>

        {/* Portfolio Items */}
        <div className="space-y-3">
          {portfolio.map((item) => {
            const currentValue = item.amount * item.currentPrice
            const pnl = currentValue - item.amount * item.purchasePrice
            const pnlPercent = ((item.currentPrice - item.purchasePrice) / item.purchasePrice) * 100

            return (
              <div key={item.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{item.symbol}</span>
                  </div>
                  <div>
                    <div className="font-semibold">{item.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {item.amount} {item.symbol}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-semibold">${currentValue.toLocaleString()}</div>
                  <div className="flex items-center gap-2">
                    <Badge variant={pnl >= 0 ? "default" : "destructive"} className="text-xs">
                      {pnl >= 0 ? "+" : ""}${Math.abs(pnl).toFixed(2)}
                    </Badge>
                    <span className={`text-sm ${pnlPercent >= 0 ? "text-green-600" : "text-red-600"}`}>
                      {pnlPercent >= 0 ? "+" : ""}
                      {pnlPercent.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
