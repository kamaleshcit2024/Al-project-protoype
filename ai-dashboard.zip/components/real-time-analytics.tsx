"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"
import { Activity, Zap, Globe, Shield } from "lucide-react"

const networkData = [
  { name: "Bitcoin", transactions: 350000, color: "hsl(var(--chart-1))" },
  { name: "Ethereum", transactions: 1200000, color: "hsl(var(--chart-2))" },
  { name: "Solana", transactions: 2800000, color: "hsl(var(--chart-3))" },
  { name: "Polygon", transactions: 1800000, color: "hsl(var(--chart-4))" },
]

const securityMetrics = [
  { name: "Network Security", value: 98, color: "hsl(var(--chart-1))" },
  { name: "Validator Uptime", value: 99.7, color: "hsl(var(--chart-2))" },
  { name: "Consensus Health", value: 96.5, color: "hsl(var(--chart-3))" },
]

export function RealTimeAnalytics() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [networkHealth, setNetworkHealth] = useState(97.8)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
      // Simulate slight variations in network health
      setNetworkHealth((prev) => prev + (Math.random() - 0.5) * 0.2)
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Network Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4 text-primary" />
            Network Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Last Updated</span>
              <Badge variant="secondary" className="text-xs">
                {currentTime.toLocaleTimeString()}
              </Badge>
            </div>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={networkData} margin={{ top: 5, right: 5, left: 5, bottom: 5 }}>
                  <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                  <YAxis tick={{ fontSize: 10 }} />
                  <Bar dataKey="transactions" fill="hsl(var(--primary))" radius={[2, 2, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {networkData.map((network) => (
                <div key={network.name} className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ backgroundColor: network.color }}></div>
                  <span className="text-muted-foreground truncate">{network.name}</span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Security Metrics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Shield className="h-4 w-4 text-primary" />
            Security Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {securityMetrics.map((metric) => (
              <div key={metric.name} className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">{metric.name}</span>
                  <span className="font-medium">{metric.value}%</span>
                </div>
                <Progress value={metric.value} className="h-2" />
              </div>
            ))}
            <div className="pt-4 border-t">
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Overall Health</span>
                <Badge variant={networkHealth > 95 ? "default" : "secondary"} className="text-xs">
                  {networkHealth.toFixed(1)}%
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Global Stats */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            <Globe className="h-4 w-4 text-primary" />
            Global Statistics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-primary">24.7M</div>
                <div className="text-xs text-muted-foreground">Active Addresses</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-secondary">$2.1T</div>
                <div className="text-xs text-muted-foreground">Market Cap</div>
              </div>
            </div>

            <div className="h-[120px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={networkData}
                    cx="50%"
                    cy="50%"
                    innerRadius={30}
                    outerRadius={50}
                    paddingAngle={2}
                    dataKey="transactions"
                  >
                    {networkData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <Zap className="h-3 w-3 text-primary" />
              <span className="text-muted-foreground">Real-time data from 50+ networks</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
