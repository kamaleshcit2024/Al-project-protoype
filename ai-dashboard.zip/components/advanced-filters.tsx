"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Filter, Search, X, TrendingUp, TrendingDown, DollarSign, BarChart3 } from "lucide-react"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"

interface FilterState {
  search: string
  categories: string[]
  priceRange: [number, number]
  marketCapRange: [number, number]
  volumeRange: [number, number]
  changeRange: [number, number]
  sortBy: string
  sortOrder: "asc" | "desc"
  timeframe: string
}

interface CryptoAsset {
  id: string
  symbol: string
  name: string
  price: number
  marketCap: number
  volume24h: number
  change24h: number
  category: string
}

export function AdvancedFilters() {
  const [filters, setFilters] = useState<FilterState>({
    search: "",
    categories: [],
    priceRange: [0, 100000],
    marketCapRange: [0, 1000000000000],
    volumeRange: [0, 50000000000],
    changeRange: [-50, 50],
    sortBy: "marketCap",
    sortOrder: "desc",
    timeframe: "24h",
  })

  const [mockAssets] = useState<CryptoAsset[]>([
    {
      id: "1",
      symbol: "BTC",
      name: "Bitcoin",
      price: 43250,
      marketCap: 847000000000,
      volume24h: 28500000000,
      change24h: 2.3,
      category: "Layer 1",
    },
    {
      id: "2",
      symbol: "ETH",
      name: "Ethereum",
      price: 2650,
      marketCap: 318000000000,
      volume24h: 15200000000,
      change24h: -1.2,
      category: "Layer 1",
    },
    {
      id: "3",
      symbol: "ADA",
      name: "Cardano",
      price: 0.48,
      marketCap: 16800000000,
      volume24h: 420000000,
      change24h: 4.1,
      category: "Layer 1",
    },
    {
      id: "4",
      symbol: "UNI",
      name: "Uniswap",
      price: 7.2,
      marketCap: 5400000000,
      volume24h: 180000000,
      change24h: -3.5,
      category: "DeFi",
    },
    {
      id: "5",
      symbol: "LINK",
      name: "Chainlink",
      price: 14.8,
      marketCap: 8200000000,
      volume24h: 650000000,
      change24h: 1.8,
      category: "Oracle",
    },
    {
      id: "6",
      symbol: "MATIC",
      name: "Polygon",
      price: 0.85,
      marketCap: 7900000000,
      volume24h: 380000000,
      change24h: 6.2,
      category: "Layer 2",
    },
  ])

  const categories = ["Layer 1", "Layer 2", "DeFi", "Oracle", "Gaming", "NFT", "Meme"]

  const updateFilter = (key: keyof FilterState, value: any) => {
    setFilters((prev) => ({ ...prev, [key]: value }))
  }

  const toggleCategory = (category: string) => {
    const newCategories = filters.categories.includes(category)
      ? filters.categories.filter((c) => c !== category)
      : [...filters.categories, category]
    updateFilter("categories", newCategories)
  }

  const clearFilters = () => {
    setFilters({
      search: "",
      categories: [],
      priceRange: [0, 100000],
      marketCapRange: [0, 1000000000000],
      volumeRange: [0, 50000000000],
      changeRange: [-50, 50],
      sortBy: "marketCap",
      sortOrder: "desc",
      timeframe: "24h",
    })
  }

  const filteredAssets = mockAssets
    .filter((asset) => {
      const matchesSearch =
        asset.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        asset.symbol.toLowerCase().includes(filters.search.toLowerCase())
      const matchesCategory = filters.categories.length === 0 || filters.categories.includes(asset.category)
      const matchesPrice = asset.price >= filters.priceRange[0] && asset.price <= filters.priceRange[1]
      const matchesMarketCap =
        asset.marketCap >= filters.marketCapRange[0] && asset.marketCap <= filters.marketCapRange[1]
      const matchesVolume = asset.volume24h >= filters.volumeRange[0] && asset.volume24h <= filters.volumeRange[1]
      const matchesChange = asset.change24h >= filters.changeRange[0] && asset.change24h <= filters.changeRange[1]

      return matchesSearch && matchesCategory && matchesPrice && matchesMarketCap && matchesVolume && matchesChange
    })
    .sort((a, b) => {
      const aValue = a[filters.sortBy as keyof CryptoAsset] as number
      const bValue = b[filters.sortBy as keyof CryptoAsset] as number
      return filters.sortOrder === "asc" ? aValue - bValue : bValue - aValue
    })

  const formatNumber = (num: number) => {
    if (num >= 1e12) return `$${(num / 1e12).toFixed(2)}T`
    if (num >= 1e9) return `$${(num / 1e9).toFixed(2)}B`
    if (num >= 1e6) return `$${(num / 1e6).toFixed(2)}M`
    if (num >= 1e3) return `$${(num / 1e3).toFixed(2)}K`
    return `$${num.toFixed(2)}`
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Filter Panel */}
      <Card className="lg:col-span-1">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-lg font-bold flex items-center gap-2">
              <Filter className="h-4 w-4" />
              Filters
            </CardTitle>
            <CardDescription>Refine your search</CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={clearFilters}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Search */}
          <div>
            <Label className="text-sm font-medium">Search</Label>
            <div className="relative mt-2">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search assets..."
                value={filters.search}
                onChange={(e) => updateFilter("search", e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <Separator />

          {/* Categories */}
          <div>
            <Label className="text-sm font-medium">Categories</Label>
            <div className="mt-2 space-y-2">
              {categories.map((category) => (
                <div key={category} className="flex items-center space-x-2">
                  <Checkbox
                    id={category}
                    checked={filters.categories.includes(category)}
                    onCheckedChange={() => toggleCategory(category)}
                  />
                  <Label htmlFor={category} className="text-sm">
                    {category}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Price Range */}
          <div>
            <Label className="text-sm font-medium">Price Range</Label>
            <div className="mt-2 space-y-2">
              <Slider
                value={filters.priceRange}
                onValueChange={(value) => updateFilter("priceRange", value)}
                max={100000}
                step={100}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>${filters.priceRange[0]}</span>
                <span>${filters.priceRange[1].toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* 24h Change Range */}
          <div>
            <Label className="text-sm font-medium">24h Change (%)</Label>
            <div className="mt-2 space-y-2">
              <Slider
                value={filters.changeRange}
                onValueChange={(value) => updateFilter("changeRange", value)}
                min={-50}
                max={50}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>{filters.changeRange[0]}%</span>
                <span>{filters.changeRange[1]}%</span>
              </div>
            </div>
          </div>

          <Separator />

          {/* Sort Options */}
          <div>
            <Label className="text-sm font-medium">Sort By</Label>
            <div className="mt-2 space-y-2">
              <Select value={filters.sortBy} onValueChange={(value) => updateFilter("sortBy", value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketCap">Market Cap</SelectItem>
                  <SelectItem value="price">Price</SelectItem>
                  <SelectItem value="volume24h">24h Volume</SelectItem>
                  <SelectItem value="change24h">24h Change</SelectItem>
                </SelectContent>
              </Select>
              <Select
                value={filters.sortOrder}
                onValueChange={(value: "asc" | "desc") => updateFilter("sortOrder", value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="desc">Highest to Lowest</SelectItem>
                  <SelectItem value="asc">Lowest to Highest</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results Panel */}
      <Card className="lg:col-span-3">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-lg font-bold">Market Data</CardTitle>
              <CardDescription>
                Showing {filteredAssets.length} of {mockAssets.length} assets
              </CardDescription>
            </div>
            <div className="flex items-center gap-2">
              {filters.categories.map((category) => (
                <Badge key={category} variant="secondary" className="text-xs">
                  {category}
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-4 w-4 p-0 ml-1"
                    onClick={() => toggleCategory(category)}
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </Badge>
              ))}
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {filteredAssets.map((asset) => (
              <div
                key={asset.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                    <span className="text-sm font-bold text-primary">{asset.symbol}</span>
                  </div>
                  <div>
                    <div className="font-semibold">{asset.name}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {asset.category}
                      </Badge>
                    </div>
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <div className="font-semibold">${asset.price.toLocaleString()}</div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <DollarSign className="h-3 w-3" />
                      {formatNumber(asset.marketCap)}
                    </span>
                    <span className="flex items-center gap-1">
                      <BarChart3 className="h-3 w-3" />
                      {formatNumber(asset.volume24h)}
                    </span>
                    <span
                      className={`flex items-center gap-1 ${asset.change24h >= 0 ? "text-green-600" : "text-red-600"}`}
                    >
                      {asset.change24h >= 0 ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                      {asset.change24h >= 0 ? "+" : ""}
                      {asset.change24h.toFixed(2)}%
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
