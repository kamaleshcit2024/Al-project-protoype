"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, Clock, DollarSign, Leaf, Award } from "lucide-react"

const results = [
  {
    title: "AI Recommended Route",
    type: "optimal",
    cost: "$12.45",
    time: "3.2 min",
    carbon: "0.8 kg CO₂",
    savings: "40%",
    route: "ETH → Polygon → Arbitrum",
    score: 94,
  },
  {
    title: "Your Selected Route",
    type: "user",
    cost: "$20.80",
    time: "5.7 min",
    carbon: "1.2 kg CO₂",
    savings: "0%",
    route: "ETH → Arbitrum",
    score: 67,
  },
]

export function OptimizationResults() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="h-5 w-5 text-primary" />
          Route Comparison
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {results.map((result, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border-2 ${
              result.type === "optimal" ? "border-green-500/50 bg-green-500/5" : "border-muted bg-muted/20"
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold flex items-center gap-2">
                {result.title}
                {result.type === "optimal" && (
                  <Badge className="bg-green-500 hover:bg-green-600">
                    <Award className="h-3 w-3 mr-1" />
                    Recommended
                  </Badge>
                )}
              </h3>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Optimization Score</div>
                <div className="text-lg font-bold">{result.score}/100</div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-green-500" />
                <div>
                  <div className="text-sm text-muted-foreground">Cost</div>
                  <div className="font-semibold">{result.cost}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-blue-500" />
                <div>
                  <div className="text-sm text-muted-foreground">Time</div>
                  <div className="font-semibold">{result.time}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Leaf className="h-4 w-4 text-emerald-500" />
                <div>
                  <div className="text-sm text-muted-foreground">Carbon</div>
                  <div className="font-semibold">{result.carbon}</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-purple-500" />
                <div>
                  <div className="text-sm text-muted-foreground">Savings</div>
                  <div className="font-semibold text-green-600">{result.savings}</div>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Route: {result.route}</span>
                <span>{result.score}%</span>
              </div>
              <Progress value={result.score} className="h-2" />
            </div>

            {result.type === "optimal" && (
              <div className="mt-3 p-3 bg-green-500/10 rounded-lg">
                <p className="text-sm text-green-700 dark:text-green-300">
                  <strong>Why this route?</strong> This path saves 40% on gas fees and reduces carbon footprint by 25%
                  through optimized bridge selection and timing.
                </p>
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
