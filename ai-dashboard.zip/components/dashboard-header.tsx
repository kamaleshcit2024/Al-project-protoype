import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Activity, Brain, TrendingUp } from "lucide-react"

export function DashboardHeader() {
  return (
    <header className="border-b bg-card/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Brain className="h-8 w-8 text-primary" />
              <h1 className="text-2xl font-bold text-balance">ECOnodes.AI</h1>
            </div>
            <Badge variant="secondary" className="ml-2">
              <Activity className="h-3 w-3 mr-1" />
              Live
            </Badge>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" size="sm">
              <TrendingUp className="h-4 w-4 mr-2" />
              Export Data
            </Button>
            <Button size="sm">Connect Wallet</Button>
          </div>
        </div>
      </div>
    </header>
  )
}
