"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Brain, Send, Loader2, CheckCircle, AlertCircle } from "lucide-react"

interface ProcessingStep {
  id: string
  title: string
  status: "pending" | "processing" | "completed" | "error"
  description: string
}

export function AIProcessingInterface() {
  const [query, setQuery] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [steps, setSteps] = useState<ProcessingStep[]>([])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!query.trim() || isProcessing) return

    setIsProcessing(true)
    const processingSteps: ProcessingStep[] = [
      {
        id: "1",
        title: "Analyzing Query",
        status: "processing",
        description: "Understanding your blockchain analysis request...",
      },
      {
        id: "2",
        title: "Fetching Data",
        status: "pending",
        description: "Retrieving real-time blockchain data...",
      },
      {
        id: "3",
        title: "AI Analysis",
        status: "pending",
        description: "Running AI models on the data...",
      },
      {
        id: "4",
        title: "Generating Insights",
        status: "pending",
        description: "Creating actionable insights and predictions...",
      },
    ]

    setSteps(processingSteps)

    // Simulate processing steps
    for (let i = 0; i < processingSteps.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      setSteps((prev) =>
        prev.map((step, index) => {
          if (index === i) {
            return { ...step, status: "completed" }
          } else if (index === i + 1) {
            return { ...step, status: "processing" }
          }
          return step
        }),
      )
    }

    setIsProcessing(false)
    setQuery("")
  }

  const getStatusIcon = (status: ProcessingStep["status"]) => {
    switch (status) {
      case "processing":
        return <Loader2 className="h-4 w-4 animate-spin text-primary" />
      case "completed":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "error":
        return <AlertCircle className="h-4 w-4 text-red-500" />
      default:
        return <div className="h-4 w-4 rounded-full border-2 border-muted-foreground/30" />
    }
  }

  const getStatusBadge = (status: ProcessingStep["status"]) => {
    switch (status) {
      case "processing":
        return <Badge variant="secondary">Processing</Badge>
      case "completed":
        return <Badge className="bg-green-500/10 text-green-700 hover:bg-green-500/20">Completed</Badge>
      case "error":
        return <Badge variant="destructive">Error</Badge>
      default:
        return <Badge variant="outline">Pending</Badge>
    }
  }

  return (
    <Card className="h-[500px] flex flex-col">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-primary" />
          ECOnodes.AI Processing Center
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-4">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            placeholder="Ask AI to analyze blockchain patterns, predict trends..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={isProcessing}
            className="flex-1"
          />
          <Button type="submit" disabled={isProcessing || !query.trim()}>
            {isProcessing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </form>

        <ScrollArea className="flex-1">
          {steps.length > 0 ? (
            <div className="space-y-4">
              {steps.map((step) => (
                <div key={step.id} className="flex items-start gap-3 p-3 rounded-lg border bg-card/50">
                  <div className="mt-0.5">{getStatusIcon(step.status)}</div>
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-sm">{step.title}</h4>
                      {getStatusBadge(step.status)}
                    </div>
                    <p className="text-xs text-muted-foreground">{step.description}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-center">
              <div className="space-y-2">
                <Brain className="h-12 w-12 text-muted-foreground/50 mx-auto" />
                <p className="text-sm text-muted-foreground">Enter a query to start AI analysis</p>
                <p className="text-xs text-muted-foreground/70">
                  Try: "Analyze Bitcoin price trends" or "Predict DeFi market movements"
                </p>
              </div>
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
