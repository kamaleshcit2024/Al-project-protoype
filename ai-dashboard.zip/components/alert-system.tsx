"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Bell, Plus, Trash2, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"

interface Alert {
  id: string
  name: string
  asset: string
  condition: "above" | "below" | "change_up" | "change_down"
  value: number
  isActive: boolean
  triggered: boolean
  createdAt: Date
}

export function AlertSystem() {
  const { toast } = useToast()
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: "1",
      name: "BTC Price Alert",
      asset: "BTC",
      condition: "above",
      value: 45000,
      isActive: true,
      triggered: false,
      createdAt: new Date(),
    },
    {
      id: "2",
      name: "ETH Drop Alert",
      asset: "ETH",
      condition: "below",
      value: 2500,
      isActive: true,
      triggered: true,
      createdAt: new Date(),
    },
  ])

  const [newAlert, setNewAlert] = useState({
    name: "",
    asset: "BTC",
    condition: "above" as const,
    value: "",
  })

  const [recentNotifications, setRecentNotifications] = useState([
    { id: "1", message: "ETH dropped below $2,500", time: "2 minutes ago", type: "warning" },
    { id: "2", message: "BTC volume increased by 15%", time: "5 minutes ago", type: "info" },
    { id: "3", message: "ADA price increased by 8%", time: "12 minutes ago", type: "success" },
  ])

  const addAlert = () => {
    if (newAlert.name && newAlert.value) {
      const alert: Alert = {
        id: Date.now().toString(),
        name: newAlert.name,
        asset: newAlert.asset,
        condition: newAlert.condition,
        value: Number.parseFloat(newAlert.value),
        isActive: true,
        triggered: false,
        createdAt: new Date(),
      }
      setAlerts([...alerts, alert])
      setNewAlert({ name: "", asset: "BTC", condition: "above", value: "" })
      toast({
        title: "Alert Created",
        description: `${newAlert.name} has been added to your alerts.`,
      })
    }
  }

  const toggleAlert = (id: string) => {
    setAlerts(alerts.map((alert) => (alert.id === id ? { ...alert, isActive: !alert.isActive } : alert)))
  }

  const deleteAlert = (id: string) => {
    setAlerts(alerts.filter((alert) => alert.id !== id))
    toast({
      title: "Alert Deleted",
      description: "The alert has been removed from your list.",
    })
  }

  const getConditionIcon = (condition: string) => {
    switch (condition) {
      case "above":
      case "change_up":
        return <TrendingUp className="h-4 w-4" />
      case "below":
      case "change_down":
        return <TrendingDown className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getConditionText = (condition: string) => {
    switch (condition) {
      case "above":
        return "Above"
      case "below":
        return "Below"
      case "change_up":
        return "Increase by"
      case "change_down":
        return "Decrease by"
      default:
        return condition
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Alert Management */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Price Alerts
            </CardTitle>
            <CardDescription>Set up custom alerts for price movements</CardDescription>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="sm" className="gap-2">
                <Plus className="h-4 w-4" />
                New Alert
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Alert</DialogTitle>
                <DialogDescription>Set up a price or change alert for any cryptocurrency</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="alertName">Alert Name</Label>
                  <Input
                    id="alertName"
                    placeholder="BTC Price Alert"
                    value={newAlert.name}
                    onChange={(e) => setNewAlert({ ...newAlert, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="asset">Asset</Label>
                  <Select value={newAlert.asset} onValueChange={(value) => setNewAlert({ ...newAlert, asset: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BTC">Bitcoin (BTC)</SelectItem>
                      <SelectItem value="ETH">Ethereum (ETH)</SelectItem>
                      <SelectItem value="ADA">Cardano (ADA)</SelectItem>
                      <SelectItem value="SOL">Solana (SOL)</SelectItem>
                      <SelectItem value="DOT">Polkadot (DOT)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="condition">Condition</Label>
                  <Select
                    value={newAlert.condition}
                    onValueChange={(value: any) => setNewAlert({ ...newAlert, condition: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="above">Price goes above</SelectItem>
                      <SelectItem value="below">Price goes below</SelectItem>
                      <SelectItem value="change_up">Price increases by %</SelectItem>
                      <SelectItem value="change_down">Price decreases by %</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="value">
                    {newAlert.condition.includes("change") ? "Percentage (%)" : "Price ($)"}
                  </Label>
                  <Input
                    id="value"
                    type="number"
                    step={newAlert.condition.includes("change") ? "0.1" : "0.01"}
                    placeholder={newAlert.condition.includes("change") ? "5" : "45000"}
                    value={newAlert.value}
                    onChange={(e) => setNewAlert({ ...newAlert, value: e.target.value })}
                  />
                </div>
                <Button onClick={addAlert} className="w-full">
                  Create Alert
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </CardHeader>
        <CardContent className="space-y-4">
          {alerts.map((alert) => (
            <div key={alert.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  {getConditionIcon(alert.condition)}
                  <div>
                    <div className="font-semibold">{alert.name}</div>
                    <div className="text-sm text-muted-foreground">
                      {alert.asset} {getConditionText(alert.condition)}{" "}
                      {alert.condition.includes("change") ? `${alert.value}%` : `$${alert.value.toLocaleString()}`}
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                {alert.triggered && (
                  <Badge variant="destructive" className="text-xs">
                    Triggered
                  </Badge>
                )}
                <Switch checked={alert.isActive} onCheckedChange={() => toggleAlert(alert.id)} />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteAlert(alert.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Recent Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Recent Notifications</CardTitle>
          <CardDescription>Latest alerts and system notifications</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentNotifications.map((notification) => (
            <div key={notification.id} className="flex items-start gap-3 p-3 border rounded-lg">
              <div
                className={`w-2 h-2 rounded-full mt-2 ${
                  notification.type === "warning"
                    ? "bg-yellow-500"
                    : notification.type === "success"
                      ? "bg-green-500"
                      : "bg-blue-500"
                }`}
              />
              <div className="flex-1">
                <div className="text-sm">{notification.message}</div>
                <div className="text-xs text-muted-foreground mt-1">{notification.time}</div>
              </div>
            </div>
          ))}
          <Button variant="outline" className="w-full bg-transparent">
            View All Notifications
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
