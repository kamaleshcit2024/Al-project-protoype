"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, Zap, DollarSign, Leaf } from "lucide-react"

const chains = [
  { id: "ethereum", name: "Ethereum", symbol: "ETH", color: "bg-blue-500" },
  { id: "polygon", name: "Polygon", symbol: "MATIC", color: "bg-purple-500" },
  { id: "arbitrum", name: "Arbitrum", symbol: "ARB", color: "bg-cyan-500" },
  { id: "optimism", name: "Optimism", symbol: "OP", color: "bg-red-500" },
  { id: "avalanche", name: "Avalanche", symbol: "AVAX", color: "bg-red-600" },
  { id: "bsc", name: "BSC", symbol: "BNB", color: "bg-yellow-500" },
]

export function CrossChainInterface() {
  const [sourceChain, setSourceChain] = useState("")
  const [destChain, setDestChain] = useState("")
  const [amount, setAmount] = useState("")
  const [token, setToken] = useState("USDC")
  const [isOptimizing, setIsOptimizing] = useState(false)

  const handleOptimize = async () => {
    if (!sourceChain || !destChain || !amount) return

    setIsOptimizing(true)
    // Simulate optimization process
    await new Promise((resolve) => setTimeout(resolve, 3000))
    setIsOptimizing(false)
  }

  return (
    <Card className="h-fit">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Zap className="h-5 w-5 text-primary" />
          Transaction Setup
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Source Chain */}
        <div className="space-y-2">
          <Label htmlFor="source-chain">Source Chain</Label>
          <Select value={sourceChain} onValueChange={setSourceChain}>
            <SelectTrigger>
              <SelectValue placeholder="Select source chain" />
            </SelectTrigger>
            <SelectContent>
              {chains.map((chain) => (
                <SelectItem key={chain.id} value={chain.id}>
                  <div className="flex items-center gap-2">
                    <div className={`w-3 h-3 rounded-full ${chain.color}`} />
                    {chain.name} ({chain.symbol})
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Arrow */}
        <div className="flex justify-center">
          <ArrowRight className="h-6 w-6 text-muted-foreground" />
        </div>

        {/* Destination Chain */}
        <div className="space-y-2">
          <Label htmlFor="dest-chain">Destination Chain</Label>
          <Select value={destChain} onValueChange={setDestChain}>
            <SelectTrigger>
              <SelectValue placeholder="Select destination chain" />
            </SelectTrigger>
            <SelectContent>
              {chains
                .filter((chain) => chain.id !== sourceChain)
                .map((chain) => (
                  <SelectItem key={chain.id} value={chain.id}>
                    <div className="flex items-center gap-2">
                      <div className={`w-3 h-3 rounded-full ${chain.color}`} />
                      {chain.name} ({chain.symbol})
                    </div>
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
        </div>

        {/* Amount and Token */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="amount">Amount</Label>
            <Input
              id="amount"
              type="number"
              placeholder="0.00"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="token">Token</Label>
            <Select value={token} onValueChange={setToken}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="USDC">USDC</SelectItem>
                <SelectItem value="USDT">USDT</SelectItem>
                <SelectItem value="ETH">ETH</SelectItem>
                <SelectItem value="WBTC">WBTC</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Optimization Priorities */}
        <div className="space-y-3">
          <Label>Optimization Priorities</Label>
          <div className="flex flex-wrap gap-2">
            <Badge variant="secondary" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              <DollarSign className="h-3 w-3 mr-1" />
              Lowest Cost
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              <Zap className="h-3 w-3 mr-1" />
              Fastest Speed
            </Badge>
            <Badge variant="outline" className="cursor-pointer hover:bg-primary hover:text-primary-foreground">
              <Leaf className="h-3 w-3 mr-1" />
              Eco-Friendly
            </Badge>
          </div>
        </div>

        {/* Optimize Button */}
        <Button
          onClick={handleOptimize}
          disabled={!sourceChain || !destChain || !amount || isOptimizing}
          className="w-full"
          size="lg"
        >
          {isOptimizing ? (
            <>
              <Zap className="h-4 w-4 mr-2 animate-pulse" />
              Optimizing Route...
            </>
          ) : (
            <>
              <Zap className="h-4 w-4 mr-2" />
              Find Optimal Route
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  )
}
