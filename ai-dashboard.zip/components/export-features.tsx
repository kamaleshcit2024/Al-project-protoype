"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Download, FileText, ImageIcon, BarChart3, Calendar, Settings } from "lucide-react"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"

interface ExportOptions {
  format: "pdf" | "csv" | "json" | "png"
  dateRange: string
  includeCharts: boolean
  includePortfolio: boolean
  includeAlerts: boolean
  includeAnalytics: boolean
}

export function ExportFeatures() {
  const { toast } = useToast()
  const [exportOptions, setExportOptions] = useState<ExportOptions>({
    format: "pdf",
    dateRange: "7d",
    includeCharts: true,
    includePortfolio: true,
    includeAlerts: false,
    includeAnalytics: true,
  })

  const [isExporting, setIsExporting] = useState(false)

  const exportFormats = [
    { value: "pdf", label: "PDF Report", icon: FileText, description: "Comprehensive report with charts and data" },
    { value: "csv", label: "CSV Data", icon: BarChart3, description: "Raw data for spreadsheet analysis" },
    { value: "json", label: "JSON Export", icon: Settings, description: "Structured data for developers" },
    { value: "png", label: "PNG Image", icon: ImageIcon, description: "Dashboard screenshot" },
  ]

  const dateRanges = [
    { value: "1d", label: "Last 24 Hours" },
    { value: "7d", label: "Last 7 Days" },
    { value: "30d", label: "Last 30 Days" },
    { value: "90d", label: "Last 3 Months" },
    { value: "1y", label: "Last Year" },
    { value: "all", label: "All Time" },
  ]

  const recentExports = [
    {
      id: "1",
      name: "Portfolio Report - March 2024",
      format: "pdf",
      size: "2.4 MB",
      date: "2024-03-15",
      status: "completed",
    },
    {
      id: "2",
      name: "Trading Data Export",
      format: "csv",
      size: "856 KB",
      date: "2024-03-14",
      status: "completed",
    },
    {
      id: "3",
      name: "Dashboard Screenshot",
      format: "png",
      size: "1.2 MB",
      date: "2024-03-13",
      status: "completed",
    },
  ]

  const handleExport = async () => {
    setIsExporting(true)

    // Simulate export process
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const formatLabel = exportFormats.find((f) => f.value === exportOptions.format)?.label

    toast({
      title: "Export Completed",
      description: `Your ${formatLabel} has been generated and downloaded.`,
    })

    setIsExporting(false)
  }

  const updateOption = (key: keyof ExportOptions, value: any) => {
    setExportOptions((prev) => ({ ...prev, [key]: value }))
  }

  const getFormatIcon = (format: string) => {
    const formatData = exportFormats.find((f) => f.value === format)
    const Icon = formatData?.icon || FileText
    return <Icon className="h-4 w-4" />
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Export Configuration */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Data
          </CardTitle>
          <CardDescription>Generate reports and export your dashboard data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Export Format Selection */}
          <div>
            <Label className="text-sm font-medium">Export Format</Label>
            <div className="mt-2 grid grid-cols-2 gap-2">
              {exportFormats.map((format) => {
                const Icon = format.icon
                return (
                  <div
                    key={format.value}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      exportOptions.format === format.value
                        ? "border-primary bg-primary/5"
                        : "border-border hover:bg-muted/50"
                    }`}
                    onClick={() => updateOption("format", format.value)}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Icon className="h-4 w-4" />
                      <span className="text-sm font-medium">{format.label}</span>
                    </div>
                    <p className="text-xs text-muted-foreground">{format.description}</p>
                  </div>
                )
              })}
            </div>
          </div>

          <Separator />

          {/* Date Range */}
          <div>
            <Label className="text-sm font-medium">Date Range</Label>
            <Select value={exportOptions.dateRange} onValueChange={(value) => updateOption("dateRange", value)}>
              <SelectTrigger className="mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {dateRanges.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Separator />

          {/* Include Options */}
          <div>
            <Label className="text-sm font-medium">Include in Export</Label>
            <div className="mt-2 space-y-3">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeCharts"
                  checked={exportOptions.includeCharts}
                  onCheckedChange={(checked) => updateOption("includeCharts", checked)}
                />
                <Label htmlFor="includeCharts" className="text-sm">
                  Charts and Visualizations
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includePortfolio"
                  checked={exportOptions.includePortfolio}
                  onCheckedChange={(checked) => updateOption("includePortfolio", checked)}
                />
                <Label htmlFor="includePortfolio" className="text-sm">
                  Portfolio Data
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeAlerts"
                  checked={exportOptions.includeAlerts}
                  onCheckedChange={(checked) => updateOption("includeAlerts", checked)}
                />
                <Label htmlFor="includeAlerts" className="text-sm">
                  Alert History
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="includeAnalytics"
                  checked={exportOptions.includeAnalytics}
                  onCheckedChange={(checked) => updateOption("includeAnalytics", checked)}
                />
                <Label htmlFor="includeAnalytics" className="text-sm">
                  Analytics & Metrics
                </Label>
              </div>
            </div>
          </div>

          <Separator />

          {/* Export Button */}
          <Button onClick={handleExport} disabled={isExporting} className="w-full" size="lg">
            {isExporting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                Generating Export...
              </>
            ) : (
              <>
                <Download className="h-4 w-4 mr-2" />
                Export {exportFormats.find((f) => f.value === exportOptions.format)?.label}
              </>
            )}
          </Button>

          {/* Quick Export Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <ImageIcon className="h-4 w-4" />
              Screenshot
            </Button>
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <BarChart3 className="h-4 w-4" />
              Quick CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Exports */}
      <Card>
        <CardHeader>
          <CardTitle className="text-xl font-bold">Recent Exports</CardTitle>
          <CardDescription>Your export history and downloads</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {recentExports.map((exportItem) => (
            <div key={exportItem.id} className="flex items-center justify-between p-4 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-muted rounded-lg flex items-center justify-center">
                  {getFormatIcon(exportItem.format)}
                </div>
                <div>
                  <div className="font-semibold text-sm">{exportItem.name}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-2">
                    <Calendar className="h-3 w-3" />
                    {exportItem.date}
                    <span>•</span>
                    <span>{exportItem.size}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {exportItem.format.toUpperCase()}
                </Badge>
                <Button variant="ghost" size="sm">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          <Button variant="outline" className="w-full bg-transparent">
            View All Exports
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
