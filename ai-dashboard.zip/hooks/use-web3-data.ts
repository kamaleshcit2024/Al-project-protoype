"use client"

import { useState, useEffect } from "react"
import useSWR from "swr"

interface ChainData {
  id: string
  name: string
  gasPrice: number
  blockTime: number
  congestion: "low" | "medium" | "high"
  carbonIntensity: number
}

interface BridgeRoute {
  from: string
  to: string
  protocol: string
  estimatedTime: number
  estimatedCost: number
  carbonFootprint: number
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export function useChainData(chainId: string | null) {
  return useSWR<ChainData>(chainId ? `/api/chains?chainId=${chainId}` : null, fetcher, {
    refreshInterval: 30000, // Refresh every 30 seconds
    revalidateOnFocus: false,
  })
}

export function useBridgeRoutes(fromChain: string, toChain: string, amount: string) {
  const [routes, setRoutes] = useState<BridgeRoute[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!fromChain || !toChain || !amount) {
      setRoutes([])
      return
    }

    const fetchRoutes = async () => {
      setLoading(true)
      setError(null)

      try {
        const response = await fetch("/api/bridge-routes", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ fromChain, toChain, amount }),
        })

        if (!response.ok) {
          throw new Error("Failed to fetch bridge routes")
        }

        const data = await response.json()
        setRoutes(data.routes)
      } catch (err) {
        setError(err instanceof Error ? err.message : "Unknown error")
        setRoutes([])
      } finally {
        setLoading(false)
      }
    }

    fetchRoutes()
  }, [fromChain, toChain, amount])

  return { routes, loading, error }
}

export function useCarbonFootprint(chainId: string, transactionType: string) {
  return useSWR<{ carbonFootprint: number }>(
    chainId && transactionType ? `/api/carbon-footprint` : null,
    () =>
      fetch("/api/carbon-footprint", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ chainId, transactionType }),
      }).then((res) => res.json()),
    {
      refreshInterval: 60000, // Refresh every minute
    },
  )
}
