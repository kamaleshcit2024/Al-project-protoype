import { Navigation } from "@/components/navigation"
import { UserSettings } from "@/components/user-settings"

export default function SettingsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Settings</h1>
          <p className="text-muted-foreground">Customize your ECOnodes.AI experience</p>
        </div>
        <UserSettings />
      </main>
    </div>
  )
}
