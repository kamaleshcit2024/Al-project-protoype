import { Navigation } from "@/components/navigation"
import { RealTimeAnalytics } from "@/components/real-time-analytics"
import { AdvancedFilters } from "@/components/advanced-filters"
import { ExportFeatures } from "@/components/export-features"

export default function AnalyticsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Advanced Analytics</h1>
          <p className="text-muted-foreground">Deep insights and real-time blockchain data analysis</p>
        </div>
        <AdvancedFilters />
        <RealTimeAnalytics />
        <ExportFeatures />
      </main>
    </div>
  )
}
