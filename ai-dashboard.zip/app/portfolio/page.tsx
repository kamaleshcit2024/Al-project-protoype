import { Navigation } from "@/components/navigation"
import { PortfolioTracker } from "@/components/portfolio-tracker"
import { AlertSystem } from "@/components/alert-system"

export default function PortfolioPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Portfolio Management</h1>
          <p className="text-muted-foreground">Track your investments and manage alerts</p>
        </div>
        <PortfolioTracker />
        <AlertSystem />
      </main>
    </div>
  )
}
