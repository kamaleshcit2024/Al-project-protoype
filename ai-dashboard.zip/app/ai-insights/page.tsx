import { Navigation } from "@/components/navigation"
import { AIProcessingInterface } from "@/components/ai-processing-interface"
import { DataVisualization } from "@/components/data-visualization"

export default function AIInsightsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">AI Insights</h1>
          <p className="text-muted-foreground">Advanced AI-powered blockchain analysis and predictions</p>
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <AIProcessingInterface />
          <DataVisualization />
        </div>
      </main>
    </div>
  )
}
