import { NextResponse } from "next/server"
import { CoordinatorAgent } from "@/lib/agents/coordinator-agent"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { fromChain, toChain, amount, token, userPreferences } = body

    if (!fromChain || !toChain || !amount) {
      return NextResponse.json({ error: "fromChain, toChain, and amount are required" }, { status: 400 })
    }

    const coordinator = new CoordinatorAgent()

    const context = {
      fromChain,
      toChain,
      amount: Number.parseFloat(amount),
      token: token || "USDC",
      userPreferences: {
        prioritizeCost: userPreferences?.prioritizeCost || false,
        prioritizeSpeed: userPreferences?.prioritizeSpeed || false,
        prioritizeCarbon: userPreferences?.prioritizeCarbon || false,
      },
      marketData: {}, // Could be expanded with real market data
    }

    const decision = await coordinator.analyze(context)

    return NextResponse.json({
      success: true,
      decision,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("AI optimization failed:", error)
    return NextResponse.json({ error: "Failed to optimize route" }, { status: 500 })
  }
}
