import { NextResponse } from "next/server"
import { web3API } from "@/lib/web3-api"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { chainId, transactionType } = body

    if (!chainId || !transactionType) {
      return NextResponse.json({ error: "chainId and transactionType are required" }, { status: 400 })
    }

    const carbonFootprint = await web3API.getCarbonFootprint(chainId, transactionType)
    return NextResponse.json({ carbonFootprint })
  } catch (error) {
    console.error("Error calculating carbon footprint:", error)
    return NextResponse.json({ error: "Failed to calculate carbon footprint" }, { status: 500 })
  }
}
