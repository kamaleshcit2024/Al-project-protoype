import { NextResponse } from "next/server"
import { HeuristicOptimizer } from "@/lib/optimization/heuristic-optimizer"
import { RLOptimizer } from "@/lib/optimization/reinforcement-learning"
import { RAGSystem } from "@/lib/optimization/rag-system"
import { web3API } from "@/lib/web3-api"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { fromChain, toChain, amount, optimizationMethod = "heuristic", constraints = {} } = body

    if (!fromChain || !toChain || !amount) {
      return NextResponse.json({ error: "fromChain, toChain, and amount are required" }, { status: 400 })
    }

    // Get available routes
    const routes = await web3API.getBridgeRoutes(fromChain, toChain, Number.parseFloat(amount))

    if (routes.length === 0) {
      return NextResponse.json({ error: "No routes available" }, { status: 404 })
    }

    let optimizationResult

    switch (optimizationMethod) {
      case "topsis":
        const heuristicOptimizer = new HeuristicOptimizer()
        const weights = { cost: 0.4, speed: 0.4, carbon: 0.2 }
        const topsisResults = heuristicOptimizer.optimizeWithTOPSIS(routes, weights)
        optimizationResult = {
          method: "TOPSIS",
          bestRoute: topsisResults[0],
          allScores: topsisResults,
        }
        break

      case "genetic":
        const gaOptimizer = new HeuristicOptimizer()
        const gaResult = gaOptimizer.optimizeWithGA(routes, 30, 50, 0.1)
        optimizationResult = {
          method: "Genetic Algorithm",
          bestRoute: gaResult,
          explanation: "Evolved optimal solution through genetic algorithm",
        }
        break

      case "reinforcement":
        const rlOptimizer = new RLOptimizer()
        const state = {
          fromChain,
          toChain,
          amount: Number.parseFloat(amount),
          gasPrice: 25, // Mock current gas price
          congestion: "medium",
          timeOfDay: new Date().getHours(),
        }
        const rlResult = rlOptimizer.predictOptimalRoute(state, routes)
        const rlStats = rlOptimizer.getStats()
        optimizationResult = {
          method: "Reinforcement Learning",
          bestRoute: rlResult,
          learningStats: rlStats,
        }
        break

      case "pareto":
        const paretoOptimizer = new HeuristicOptimizer()
        const paretoFrontier = paretoOptimizer.findParetoFrontier(routes)
        optimizationResult = {
          method: "Pareto Optimization",
          paretoOptimal: paretoFrontier,
          explanation: "Non-dominated solutions in cost-speed-carbon space",
        }
        break

      case "rag":
        const ragSystem = new RAGSystem()
        const ragContext = await ragSystem.retrieveRelevantContext({
          fromChain,
          toChain,
          amount: Number.parseFloat(amount),
          timeOfDay: new Date().getHours(),
        })
        const marketAnalysis = ragSystem.analyzeMarketConditions()
        const timingPrediction = ragSystem.predictOptimalTiming(fromChain, toChain)

        optimizationResult = {
          method: "RAG-Enhanced Analysis",
          context: ragContext,
          marketAnalysis,
          timingPrediction,
          bestRoute: routes[0], // Simplified for demo
        }
        break

      default:
        // Default heuristic optimization
        const defaultOptimizer = new HeuristicOptimizer()
        const filteredRoutes = defaultOptimizer.applyConstraints(routes, constraints)
        const defaultWeights = { cost: 0.4, speed: 0.4, carbon: 0.2 }
        const defaultResults = defaultOptimizer.optimizeWithTOPSIS(filteredRoutes, defaultWeights)
        optimizationResult = {
          method: "Heuristic",
          bestRoute: defaultResults[0],
          constraintsApplied: Object.keys(constraints).length > 0,
        }
    }

    return NextResponse.json({
      success: true,
      optimization: optimizationResult,
      timestamp: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Advanced optimization failed:", error)
    return NextResponse.json({ error: "Failed to optimize route" }, { status: 500 })
  }
}
