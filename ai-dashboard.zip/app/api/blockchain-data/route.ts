import { NextResponse } from "next/server"

// Mock blockchain data - in a real app, this would fetch from actual APIs
const generateMockData = () => {
  const now = Date.now()
  const data = []

  for (let i = 0; i < 24; i++) {
    const timestamp = now - (23 - i) * 60 * 60 * 1000
    data.push({
      timestamp,
      time: new Date(timestamp).toLocaleTimeString("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        hour12: false,
      }),
      btc: 42000 + Math.random() * 5000 - 2500,
      eth: 2500 + Math.random() * 500 - 250,
      sol: 95 + Math.random() * 30 - 15,
      volume: Math.random() * 1000000000,
      marketCap: Math.random() * 100000000000,
    })
  }

  return data
}

export async function GET() {
  try {
    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 500))

    const data = generateMockData()

    return NextResponse.json({
      success: true,
      data,
      timestamp: Date.now(),
    })
  } catch (error) {
    return NextResponse.json({ success: false, error: "Failed to fetch blockchain data" }, { status: 500 })
  }
}
