import { NextResponse } from "next/server"
import { web3API } from "@/lib/web3-api"

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { fromChain, toChain, amount } = body

    if (!fromChain || !toChain || !amount) {
      return NextResponse.json({ error: "fromChain, toChain, and amount are required" }, { status: 400 })
    }

    const routes = await web3API.getBridgeRoutes(fromChain, toChain, Number.parseFloat(amount))
    return NextResponse.json({ routes })
  } catch (error) {
    console.error("Error fetching bridge routes:", error)
    return NextResponse.json({ error: "Failed to fetch bridge routes" }, { status: 500 })
  }
}
