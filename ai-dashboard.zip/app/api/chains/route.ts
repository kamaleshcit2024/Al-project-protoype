import { NextResponse } from "next/server"
import { web3API } from "@/lib/web3-api"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const chainId = searchParams.get("chainId")

    if (!chainId) {
      return NextResponse.json({ error: "Chain ID is required" }, { status: 400 })
    }

    const chainData = await web3API.getChainData(chainId)
    return NextResponse.json(chainData)
  } catch (error) {
    console.error("Error fetching chain data:", error)
    return NextResponse.json({ error: "Failed to fetch chain data" }, { status: 500 })
  }
}
