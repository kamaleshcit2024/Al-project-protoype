import { Navigation } from "@/components/navigation"
import { CrossChainInterface } from "@/components/cross-chain-interface"
import { OptimizationResults } from "@/components/optimization-results"
import { TransactionPath } from "@/components/transaction-path"

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <main className="container mx-auto px-4 py-8 space-y-8">
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-foreground">Cross-Chain DeFi Optimizer</h1>
          <p className="text-muted-foreground">
            AI-powered transaction routing with cost, speed, and carbon optimization
          </p>
        </div>
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-1">
            <CrossChainInterface />
          </div>
          <div className="xl:col-span-2 space-y-6">
            <OptimizationResults />
            <TransactionPath />
          </div>
        </div>
      </main>
    </div>
  )
}
